/*
 * Copyright(c) 2007-2008. Progress Software Corporation. All Rights Reserved.
 */
package com.ddtek.xquery.webservice;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.net.URL;

import javax.xml.transform.TransformerException;
import javax.xml.transform.stream.StreamSource;

import com.ddtek.xquery.ModuleURIResolver;


public class ModuleResolver implements ModuleURIResolver {

	public StreamSource[] resolve(String moduleURI, String baseURI,
			String[] locationHints) throws TransformerException {
		
		StreamSource ret[] = new StreamSource[locationHints.length];
		for(int i = 0; i < locationHints.length; i++){
			String path = getClass().getPackage().getName().replace('.','/') + "/" + locationHints[i];
			URL url = getClass().getClassLoader().getResource(path);
			InputStream stream = getClass().getClassLoader().getResourceAsStream(path);
			Reader reader = new InputStreamReader(stream);
			ret[i] = new StreamSource(reader, url.toString());
		}
		return ret;
	}

}
