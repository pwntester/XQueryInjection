/*
 * Copyright(c) 2007-2008. Progress Software Corporation. All Rights Reserved.
 */
package com.ddtek.xquery.webservice;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

import javax.xml.namespace.QName;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.sax.SAXTransformerFactory;
import javax.xml.transform.sax.TransformerHandler;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.Attributes;
import org.xml.sax.InputSource;
import org.xml.sax.helpers.AttributesImpl;
import org.xml.sax.helpers.XMLFilterImpl;

import java.io.File;
import java.io.FileInputStream;
import java.io.FilenameFilter;
import java.io.IOException;
import java.io.FileReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.io.Reader;
import java.io.StringReader;
import java.io.StringWriter;
import java.io.Writer;

import java.sql.Connection;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Properties;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;

import com.ddtek.xquery3.ExtStaticContext;
import com.ddtek.xquery3.XQException;
import com.ddtek.xquery3.XQItem;
import com.ddtek.xquery3.XQQueryException;
import com.ddtek.xquery3.XQSequenceType;
import com.ddtek.xquery3.XQConnection;
import com.ddtek.xquery3.XQExpression;
import com.ddtek.xquery3.XQPreparedExpression;
import com.ddtek.xquery3.XQItemType;
import com.ddtek.xquery3.XQStaticContext;
import com.ddtek.xquery3.XQSequence;
import com.ddtek.xquery3.XQResultSequence;
import com.ddtek.xquery3.jdbc.XQueryConnection;
import com.ddtek.xquery3.xqj.DDXQDataSource;
import com.ddtek.xquery3.xqj.DDXQJDBCConnection;

public class XQServlet extends HttpServlet 
	implements FilenameFilter	
{
	
	private static final String QUERIES_FOLDER = "QueriesFolder";
	private static final String JNDI_DATASOURCE_NAME = "JNDIDataSourceName";
	private static final String DEFAULT_JNDI_DATASOURCE_NAME = "jdbc/XQueryWebService";
	
	static final long serialVersionUID = 1L;
	static final String XML_CONTENT_TYPE = "text/xml;";
	static final String HTML_CONTENT_TYPE = "text/html;";
	static final String SOAP_NS = "http://schemas.xmlsoap.org/soap/envelope/";
	static final String ESCAPE_BEGIN = "__X";
	static final String ESCAPE_END = "X__";
	
	DataSource m_dataSource;
	Connection m_jdbcConnection;
	DDXQDataSource m_ddxqDataSource;
	DDXQDataSource m_ddxqDataSourceNoDB;
	XQConnection m_xqConnection;
	XQItemType m_documentType;
	
	private HashMap m_queryToSchemaInfo;
	private String m_queriesFolder;
	
	public boolean accept(File dir, String name) {
		return name.endsWith(".xquery") 
				|| name.endsWith(".xqy")
				|| name.endsWith(".xq");
	}

	public void destroy(ServletConfig config) throws ServletException 
	{
		releaseConnection();
	}

	public void init(ServletConfig config) throws ServletException
	{
    	super.init(config);
		try{
		
			
			m_queryToSchemaInfo = new HashMap();
			m_ddxqDataSourceNoDB = new DDXQDataSource();
			m_ddxqDataSourceNoDB.setOptions("serialize=indent=yes");
			m_ddxqDataSourceNoDB.setMaxPooledQueries(20);
			m_ddxqDataSourceNoDB.setModuleUriResolver(ModuleResolver.class.getName());
			
			String jndiDataSourceName = config.getInitParameter(JNDI_DATASOURCE_NAME);
			if(jndiDataSourceName==null || jndiDataSourceName.length()==0)
				jndiDataSourceName = DEFAULT_JNDI_DATASOURCE_NAME; 
			
			Context initCtx, envCtx;
			try{// 1) JDNI
				initCtx = new InitialContext();
				envCtx = (Context) initCtx.lookup("java:comp/env");
				m_dataSource = (DataSource)envCtx.lookup(jndiDataSourceName);
				m_jdbcConnection = m_dataSource.getConnection();
				m_xqConnection = XQueryConnection.getXQConnection(m_jdbcConnection);
			}
			catch(Exception e){
				initCtx = null;
				envCtx = null;
				m_dataSource = null;
				if(m_jdbcConnection!=null){
					m_jdbcConnection.close();
					m_jdbcConnection = null;
				}
				e.printStackTrace();
			}
			
			m_queriesFolder = config.getInitParameter(QUERIES_FOLDER);
			
			if(m_dataSource == null){// 2) Servlet initial parameters
				
				String value;
				String name;
				DDXQJDBCConnection[] connections;
				ArrayList list = new ArrayList();
				
				
				m_ddxqDataSource = new DDXQDataSource();
				m_ddxqDataSource.setOptions("serialize=indent=yes");
				m_ddxqDataSource.setMaxPooledQueries(20);
				
				Enumeration e = config.getInitParameterNames();
				while(e.hasMoreElements()){
					name = e.nextElement().toString();
					value = config.getInitParameter(name);
					if(name.compareTo(QUERIES_FOLDER) != 0){
						DDXQJDBCConnection connection = new DDXQJDBCConnection(name);
						connection.setUrl(value);
						list.add(connection);
					}
				}
				connections = new DDXQJDBCConnection[list.size()];
				System.arraycopy(list.toArray(), 0, connections, 0, list.size());
				m_ddxqDataSource.setDdxqJdbcConnection( connections );
				m_ddxqDataSource.setBaseUri(new File(getQueriesFolder()).toURI().toURL().toString());
				m_xqConnection = m_ddxqDataSource.getConnection();
			}
			
			XQItemType type = m_xqConnection.createElementType(null, XQItemType.XQBASETYPE_UNTYPED);
			m_documentType = m_xqConnection.createDocumentElementType(type);
			
		}
		catch(Throwable e){
			throw new ServletException(e);
		}
		finally{
			releaseConnection();
		}
	}
	
	void refreshConnection() throws Exception
	{
		if(m_dataSource != null){
			try{
				m_jdbcConnection = m_dataSource.getConnection();
				m_xqConnection = XQueryConnection.getXQConnection(m_jdbcConnection);
			}
			catch(Exception t){
				if(m_jdbcConnection != null){
					try{
						m_jdbcConnection.close();
					}catch(Exception t1){ t1.printStackTrace();}
					m_jdbcConnection = null;
					m_xqConnection = null;
				}
				throw t;
			}
		}
		else{
			m_xqConnection = m_ddxqDataSource.getConnection();
		}
	}
	
	void releaseConnection()
	{
		try{
			if(m_jdbcConnection !=null){
				m_jdbcConnection.close();
				m_jdbcConnection = null;
			}
			else{
				if(m_xqConnection != null){
					m_xqConnection.close();
					m_xqConnection = null;
				}
			}
		}
		catch(Exception t){
			t.printStackTrace();
		}
	}

	synchronized public void doGet(HttpServletRequest request, HttpServletResponse response)
		throws ServletException, IOException {
		
		try {
			refreshConnection();
			doGetInternal(request, response);
		}
		catch (Exception e) {
			e.printStackTrace();
			ExceptionToFault(e, response);
		}
		finally{
			releaseConnection();
		}
		
	}
	
	void doGetInternal(HttpServletRequest request, HttpServletResponse response) throws Exception
	{
		if(request.getPathInfo()==null || request.getPathInfo().compareTo("/")==0){
			response.setContentType(HTML_CONTENT_TYPE);
			listOperations(request, response);
		}
		else{
			if(request.getPathInfo().substring(1).compareToIgnoreCase("wsdl") == 0){
				response.setContentType(XML_CONTENT_TYPE);
				generateWSDL(request, response);
			}
			else{
				String path = getQueriesFolder() + request.getPathInfo().substring(1);
				
				File f = new File(path);
				if( f.exists() 
					&& !path.endsWith(".xquery") 
					&& !path.endsWith(".xqy")
					&& !path.endsWith(".xq")){
				
					FileInputStream fis = new FileInputStream(f);
					byte buffer[] = new byte[1024];
					int nbytes;
					OutputStream os = response.getOutputStream();
					try{
						while( (nbytes = fis.read(buffer)) > -1)
							os.write(buffer,0,nbytes);
					}
					finally{
						fis.close();
					}
				
				} else if(request.getQueryString() != null || NoPametersQuery(request)){
					response.setContentType(XML_CONTENT_TYPE);
					OnHTTPGet(request, response);
				}
				else{
					response.setContentType(HTML_CONTENT_TYPE);
					OnHTTPGetUI(request, response);
				}
			}
		}
	}
	

	synchronized public void doPost(HttpServletRequest request, HttpServletResponse response)
		throws ServletException, IOException {
		response.setContentType(XML_CONTENT_TYPE);
		
		try{
			refreshConnection();
			String xqueryPath = request.getHeader("soapaction");
			if(xqueryPath != null && xqueryPath.length() > 0 )
				OnSOAPRequest(request, response);
			else
				doGetInternal(request, response);
		}
		catch(Exception e) {
			e.printStackTrace();
			ExceptionToFault(e, response);
		}
		finally{
			releaseConnection();
		}

	}

	void listOperations(HttpServletRequest request, HttpServletResponse response) throws Exception
	{
		String realpath = getQueriesFolder();
		String location = request.getRequestURL().toString();
		realpath = realpath.substring(0, realpath.length()-1);	
		File queriesFolder = new File(realpath);
		if(!queriesFolder.exists())
			throw new RuntimeException("Folder \"" + realpath + "\" does not exists");
			
		File queryFiles[] = queriesFolder.listFiles(this);
		List list = new ArrayList();
		for (int i = 0; i < queryFiles.length; i++){
			String path = queryFiles[i].getCanonicalPath();
			list.add(m_xqConnection.createItemFromString(path, null));
		}
		XQSequence files = m_xqConnection.createSequence(list.iterator());
		XQPreparedExpression expr = getExpressionNoDB(getQuery("list.xquery"));
		expr.bindString(new QName("location"), location, null);
		expr.bindString(new QName("fileSeparator"), File.separator, null);
		expr.bindSequence(new QName("queryFiles"), files);
		//Probe query before start sending the result
		expr.executeQuery().writeSequenceToSAX(new XMLFilterImpl());
		Writer writer = 	response.getWriter();
		expr.executeQuery().writeSequence(writer, null);
	}


	void OnHTTPGetUI(HttpServletRequest request, HttpServletResponse response) throws Exception
	{
		XQPreparedExpression expr = getExpressionNoDB(getQuery("httpgetUI.xquery"));
		String xqueryPath = request.getPathInfo().substring(1);
		xqueryPath = getQueriesFolder() + xqueryPath;
		Writer writer = response.getWriter();
		expr.bindString(new QName("url"), request.getPathInfo().substring(1), null);
		expr.bindDocument(new QName("variablesAsXML"), new DOMSource(getVariablesAsXML(xqueryPath)));
		expr.executeQuery().writeSequence(writer, null);
		writer.flush();
		expr.close();
	}
	
	boolean NoPametersQuery(HttpServletRequest request) throws Exception
	{
		String xqueryPath = request.getPathInfo().substring(1);
		xqueryPath = getQueriesFolder() + xqueryPath;
		XQPreparedExpression expr = getExpression(xqueryPath);
		return expr.getAllExternalVariables().length == 0; 
	}
	
	void OnHTTPGet(HttpServletRequest request, HttpServletResponse response) throws Exception
	{
		String xqueryPath = request.getPathInfo().substring(1);
		xqueryPath = getQueriesFolder() + xqueryPath;
		XQPreparedExpression expr = getExpression(xqueryPath);
		Enumeration e = request.getParameterNames();
		while(e.hasMoreElements()){
			String name = e.nextElement().toString();
			QName qname = QName.valueOf(name);
			XQSequenceType xqSeqType = expr.getStaticVariableType(qname);
			XQItemType xqItemType = xqSeqType.getItemType();
			if(xqItemType!=null){
				switch(xqItemType.getItemKind()){
					case XQItemType.XQITEMKIND_ATOMIC:
						expr.bindAtomicValue(qname, request.getParameter(name), xqItemType);
					break;
					case XQItemType.XQITEMKIND_ITEM:{
						XQExpression seqExpr = m_xqConnection.createExpression();
						XQSequence seq = seqExpr.executeQuery(request.getParameter(name));
						expr.bindSequence(qname, m_xqConnection.createSequence(seq)); 
						seqExpr.close();
						break;
					}
					case XQItemType.XQITEMKIND_DOCUMENT:
					case XQItemType.XQITEMKIND_DOCUMENT_ELEMENT:{
						expr.bindDocument(qname,new DOMSource(newDocument(request.getParameter(name))));
					}
					break;
					case XQItemType.XQITEMKIND_ELEMENT:
					case XQItemType.XQITEMKIND_NODE:{
						Document document = newDocument(request.getParameter(name));
						expr.bindNode(qname, document.getDocumentElement(), xqItemType);	
					}
				}
			}
			
		}

		//Probe query before start sending XML to the wire
		StringWriter tempResult  = new StringWriter();
		Element resultInfo = (Element) getResultSchemaInfo(xqueryPath);
		boolean isHTML = isOutputHTML(xqueryPath); 
		response.setContentType((isHTML) ? HTML_CONTENT_TYPE : XML_CONTENT_TYPE);
		
		boolean wrappedResult = resultInfo == null && !isHTML;
		if(wrappedResult)
			tempResult.write("\n<dd:Output xmlns:dd='http://www.datadirect.com'>\n");
		expr.executeQuery().writeSequence(tempResult, null);
		expr.close();
		if(wrappedResult)
			tempResult.write("\n</dd:Output>");
		
		sendResponse(request, response, tempResult.getBuffer().toString());
	}
	
	void OnSOAPRequest(HttpServletRequest request, HttpServletResponse response) 
		throws Exception{
		
		String xqueryPath = request.getHeader("soapaction");
		xqueryPath = xqueryPath.replaceAll("\"", "");
		xqueryPath = getQueriesFolder() + xqueryPath;
		XQPreparedExpression expr = getExpression(xqueryPath);
		
		
		XQPreparedExpression expr0 = getExpressionNoDB(getQuery("processSOAPRequest.xquery"));
		expr0.bindDocument(new QName("soapRequest"), getRequest(request));

		//Pre process SOAP Request to ignore whitespace characters and indentation 
		XQResultSequence soapPayload = expr0.executeQuery();
		
		// Read message parts and bind them to the query parameters
		while (soapPayload.next()) {
			
			Node metaNode = soapPayload.getNode();
			Node partNode = metaNode.getFirstChild();
			
			String name = metaNode.getAttributes().getNamedItem("name").getNodeValue();
			name = NCNameToString(name);
			QName qname = QName.valueOf(name);
			XQSequenceType xqSeqType = expr.getStaticVariableType(qname);
			XQItemType xqItemType = xqSeqType.getItemType();
			
			if(partNode==null || 
			   ("atomicType".compareTo(metaNode.getLocalName())==0 && partNode.getNodeValue()==null)){
				throw new IllegalArgumentException("Illegal or missing value for parameter \"" + qname + "\"");	
			}
			
			if(xqItemType!=null){
				switch(xqItemType.getItemKind()){
					case XQItemType.XQITEMKIND_ATOMIC:
						expr.bindAtomicValue(qname, partNode.getNodeValue(), xqItemType);
					break;
					case XQItemType.XQITEMKIND_ITEM:{
						XQExpression seqExpr = m_xqConnection.createExpression();
						seqExpr.bindNode(new QName("seq"), metaNode, null);
						XQSequence seq = seqExpr.executeQuery("declare variable $seq as node() external; $seq/node()");
						expr.bindSequence(qname, m_xqConnection.createSequence(seq)); 
						seqExpr.close();
						break;
					}
					case XQItemType.XQITEMKIND_DOCUMENT:
					case XQItemType.XQITEMKIND_DOCUMENT_ELEMENT:{
						Document document = newDocument();
						document.appendChild(document.importNode(partNode, true));
						expr.bindDocument(qname,new DOMSource(document));
					}
					break;
					case XQItemType.XQITEMKIND_COMMENT:
					case XQItemType.XQITEMKIND_PI:
					case XQItemType.XQITEMKIND_TEXT:
					case XQItemType.XQITEMKIND_ELEMENT:
					case XQItemType.XQITEMKIND_ATTRIBUTE:
					case XQItemType.XQITEMKIND_NODE:{
						NodeList nd = metaNode.getChildNodes();
						ArrayList list = new ArrayList();
						XQItem xqItem; 
						for(int index = 0; index < nd.getLength();index++){
							xqItem = m_xqConnection.createItemFromNode(nd.item(index), xqItemType);
							list.add(xqItem);
						}
						expr.bindSequence(qname, m_xqConnection.createSequence(list.iterator()));	
					}
				}
			}
		}
		
		//Probe query before start sending XML to the wire
		StringWriter tempResult  = new StringWriter();
				
		tempResult.write("\n<SOAP-ENV:Envelope xmlns:SOAP-ENV='http://schemas.xmlsoap.org/soap/envelope/'>");
		tempResult.write("\n<SOAP-ENV:Body>");
	
		boolean wrappedResult = getResultSchemaInfo(xqueryPath) == null;
		if(wrappedResult)
			tempResult.write("\n<dd:Output xmlns:dd='http://www.datadirect.com'>\n");
		
		expr.executeQuery().writeSequence(tempResult, null);
		expr.close();
		
		if(wrappedResult)
			tempResult.write("\n</dd:Output>");
		
		tempResult.write("\n</SOAP-ENV:Body>");
		tempResult.write("\n</SOAP-ENV:Envelope>");
		
		sendResponse(request, response, tempResult.getBuffer().toString());
	}

	void generateWSDL(HttpServletRequest request, HttpServletResponse response) throws Exception 
	{
		String realpath = getQueriesFolder();
		String location = request.getRequestURL().toString();
		
		realpath = realpath.substring(0, realpath.length()-1);	
		System.out.println("realpath " + realpath);
		File queriesFolder = new File(realpath);
		File queryFiles[] = queriesFolder.listFiles(this);
		List list = new ArrayList();
		List xsdImports = new ArrayList();
		List allVariablesAsXML = new ArrayList();
		for (int i = 0; i < queryFiles.length; i++){
			String path = queryFiles[i].getCanonicalPath();
			list.add(m_xqConnection.createItemFromString(path, null));
			Node nodeSchemaInfo = getResultSchemaInfo(path);
			if(nodeSchemaInfo!=null){
				QName qname = new QName(nodeSchemaInfo.getNamespaceURI(), nodeSchemaInfo.getLocalName());
				XQItemType elementType = m_xqConnection.createElementType(qname,XQItemType.XQBASETYPE_UNTYPED);
				xsdImports.add(m_xqConnection.createItemFromNode(nodeSchemaInfo, elementType));
			}
			Document nodeVariablesAsXML = getVariablesAsXML(path);
			if(nodeVariablesAsXML!=null)
				allVariablesAsXML.add(m_xqConnection.createItemFromDocument(new DOMSource(nodeVariablesAsXML)));	
		}
		
		XQSequence files = m_xqConnection.createSequence(list.iterator());
		XQPreparedExpression expr0 = getExpressionNoDB(getQuery("queryInfo.xquery"));
		expr0.bindSequence(new QName("queryFiles"), files);
		expr0.bindString(new QName("fileSeparator"), File.separator, null);
		expr0.bindSequence(new QName("xsdImports"), m_xqConnection.createSequence(xsdImports.iterator()));
		expr0.bindSequence(new QName("allVariablesAsXML"), m_xqConnection.createSequence(allVariablesAsXML.iterator()));
		XQSequence queryInfo  = m_xqConnection.createSequence( expr0.executeQuery() );
		
		StringWriter sw = new StringWriter();
		XQPreparedExpression expr1 = getExpressionNoDB(getQuery("dynamicNS.xquery"));
		expr1.bindSequence(new QName("queryFiles"), queryInfo);
		expr1.executeQuery().writeSequence(sw, new Properties());
		String dymanicNamespaces=sw.toString();
		
		queryInfo = m_xqConnection.createSequence( expr0.executeQuery() );
		
		Reader freader = getQuery("XQToWSDL.xquery");
		StringBuffer buffer = new StringBuffer(); 
		char chars[] = new char[1024];
		int nchars;
		while( (nchars = freader.read(chars)) != -1)
			buffer.append(chars, 0, nchars);
		freader.close();
		String toString = buffer.toString();
		
		System.out.println("dymanicNamespaces " + dymanicNamespaces); 
		
		toString = toString.replaceAll("xmlns:dynamic='DYNAMIC_NAMESPACE_DECLARATIONS'", dymanicNamespaces);
		StringReader reader = new StringReader(toString);
		
		XQPreparedExpression expr = getExpressionNoDB(reader);
		expr.bindString(new QName("targetNamespace"),"http://www.datadirect.com", null);
		expr.bindString(new QName("location"), location, null);
		expr.bindSequence(new QName("queryFiles"), queryInfo);
				
		//Probe query before start sending WSDL
		expr.executeQuery().writeSequenceToSAX(new XMLFilterImpl());
		
		Writer writer = 	response.getWriter();
		expr.executeQuery().writeSequence(writer, null);

		writer.flush();
		queryInfo.close();
	}

	/* 
	 *  getVariablesAsXML is called from the query 
	 *  that generates the WSDL document
	 *  */	
	public Document getVariablesAsXML(String queryFile) throws Exception 
	{
		XQSequenceType seqType;
		XQItemType itemType;
		XQPreparedExpression e = getExpression(queryFile);
		
		QName varNames[] = e.getAllExternalVariables();
		
		Document result = newDocument();
		Element root = result.createElement("Variables");
		root.setAttribute("queryFile", queryFile);
		result.appendChild(root);
		for (int i = 0; i < varNames.length; i++) {
			if ((seqType = e.getStaticVariableType(varNames[i])) != null 
				&& (itemType = seqType.getItemType()) != null){
				Element elementVar = result.createElement("varDecl");
				elementVar.setAttribute("localName", varNames[i].getLocalPart());
				elementVar.setAttribute("localNameNS", varNames[i].getNamespaceURI());
				elementVar.setAttribute("fullName", varNames[i].toString());
				elementVar.setAttribute("fullNameEscaped", makeNCName(varNames[i].toString()));
				switch(itemType.getItemKind()){
					case XQItemType.XQITEMKIND_DOCUMENT_ELEMENT: 
					case XQItemType.XQITEMKIND_ELEMENT:
					case XQItemType.XQITEMKIND_ATTRIBUTE: 
					case XQItemType.XQITEMKIND_ATOMIC:{
						elementVar.setAttribute("typeLocalName", itemType.getTypeName().getLocalPart());
						elementVar.setAttribute("typeNS", itemType.getTypeName().getNamespaceURI());
						elementVar.setAttribute("baseType", Integer.toString(itemType.getBaseType()));
						break;
					}
					default:
						elementVar.setAttribute("typeLocalName", "");
						elementVar.setAttribute("typeNS", "");
						elementVar.setAttribute("baseType", "");
				}
				elementVar.setAttribute("itemKind", Integer.toString(itemType.getItemKind()));
				root.appendChild(elementVar);
			}
		}
		
		//BEGIN DEBUG
		XQExpression debug = m_xqConnection.createExpression();
		debug.bindDocument(new QName("variables"), new DOMSource(result));
		debug.executeQuery("declare variable $variables external; $variables").writeSequence(System.out, new Properties());
		//END DEBUG
		
		return result;
		
	}
		
	XQPreparedExpression getExpressionNoDB(Reader queryReader) throws Exception 
	{
		XQConnection xqConnection = m_ddxqDataSourceNoDB.getConnection();
		XQStaticContext context = xqConnection.getStaticContext();
		context.setContextItemStaticType(m_documentType);
		return xqConnection.prepareExpression(queryReader, context);
	} 
	
	XQPreparedExpression getExpression(Reader queryReader) throws Exception 
	{
		XQStaticContext context = m_xqConnection.getStaticContext();
		context.setContextItemStaticType(m_documentType);
		XQPreparedExpression ret = null;
		try{
			ret = m_xqConnection.prepareExpression(queryReader, context);
		}catch(XQException xqe){
			
			// [ME0017][DataDirect][XQuery]A library module cannot be executed as a stand-alone XQuery.
			if( xqe.getVendorCode().compareTo("ME0017") == 0 )
				ret = m_xqConnection.prepareExpression(new StringReader("()"), context);
			else
				throw xqe;
		}
		return ret;
	}

	XQPreparedExpression getExpression(String xqueryPath) throws Exception 
	{
		XQPreparedExpression result;
		Reader queryReader = new FileReader(xqueryPath);
		try {
			result = getExpression(queryReader);
		}
		finally{
			queryReader.close();
		}
		return result;
	}
	
	public QName getResultQName(String xqueryPath) throws Exception
	{
		XQPreparedExpression expr = getExpression(xqueryPath);
		XQSequenceType xqst = expr.getStaticResultType();
		XQItemType xqit = xqst.getItemType();
		if(	xqit == null 
			||  (xqit.getItemKind() != XQItemType.XQITEMKIND_DOCUMENT_ELEMENT
			&&	xqit.getItemKind() != XQItemType.XQITEMKIND_ELEMENT
			&&	xqit.getItemKind() != XQItemType.XQITEMKIND_ATTRIBUTE))
			return null;
		return xqit.getNodeName();
	}
	
	public Node getResultSchemaInfo(String xqueryPath) throws Exception
	{
		Node ret;
		ret = (Node) m_queryToSchemaInfo.get(xqueryPath);
		if(ret!=null)
			return ret;
		
		QName qname = getResultQName(xqueryPath);
		if(qname == null)
			return null;
		
		String realpath = getQueriesFolder();
		realpath = realpath.substring(0, realpath.length()-1);	
		XQPreparedExpression expr1 = getExpression(getQuery("findXSD.xquery"));
		realpath = new File(realpath).toURI().toString();
		XQItemType itemtype = m_xqConnection.createAtomicType(XQItemType.XQBASETYPE_QNAME);
		expr1.bindString(new QName("xqueryPath"), xqueryPath, null);
		expr1.bindString(new QName("xsdFolder"), realpath, null);
		expr1.bindObject(new QName("globalElement"), qname, itemtype);
		XQResultSequence result = expr1.executeQuery();
		if(result.next()){
			ret = result.getNode();
			m_queryToSchemaInfo.put(xqueryPath, ret);
		}
		return ret;
	}
	
	boolean isOutputHTML(String xqueryPath) throws Exception
	{
		XQPreparedExpression expr = getExpression(xqueryPath);
		ExtStaticContext sc = (ExtStaticContext) expr.getStaticContext();
		String s = sc.getOption(new QName("http://www.datadirect.com/xquery", "serialize"));
		Properties options = new Properties();
		if(s!=null){
			String opts[] = s.split(",");
			for(int i=0; i < opts.length; i++){
				String NameValuePair[] = opts[i].split("=");	
				if(NameValuePair.length == 2){
					options.setProperty(
							NameValuePair[0].trim(), 
							NameValuePair[1].trim()); 
				}	              	
			}
		}
		String method = options.getProperty("method");
		return (method != null) ? "html".compareTo(method) == 0 : false;
	}
	
	void ExceptionToFault(Exception e, HttpServletResponse response) 
	{
		try{
			Writer writer = response.getWriter();
			SAXTransformerFactory stf = (SAXTransformerFactory) TransformerFactory.newInstance();
			String faultString = "";
			StringWriter sw = new StringWriter();
			e.printStackTrace(new PrintWriter(sw));
			String faultStack = sw.toString();
			
			String vendorCode = "";
			if(e instanceof XQQueryException)
				vendorCode = ((XQQueryException)e).getErrorCode().toString();
			else if (e instanceof XQException)
				vendorCode = ((XQException)e).getVendorCode();
			
			faultString += e.getMessage() != null ? e.getMessage() : "";
			
			TransformerHandler th = stf.newTransformerHandler();
			th.setResult(new StreamResult(writer));
			Attributes attrs = new AttributesImpl();
			th.startDocument();
				th.startElement(SOAP_NS, "Envelope", "SOAP-ENV:Envelope", attrs);
					th.startElement(SOAP_NS, "Body", "SOAP-ENV:Body", attrs);
						th.startElement(SOAP_NS, "Fault", "SOAP-ENV:Fault", attrs);
						th.startElement("", "faultcode", "faultcode", attrs);
							th.characters(vendorCode.toCharArray(), 0, vendorCode.toCharArray().length);
						th.endElement("", "faultcode", "faultcode");
						th.startElement("", "faultstring", "faultstring", attrs);
							th.characters(faultString.toCharArray(), 0, faultString.toCharArray().length);
						th.endElement("", "faultstring", "faultstring");
						th.startElement("", "faultactor", "faultactor", attrs);
							th.characters(faultStack.toCharArray(), 0, faultStack.toCharArray().length);
						th.endElement("", "faultactor", "faultactor");
						th.endElement(SOAP_NS, "Fault", "SOAP-ENV:Fault");
					th.endElement(SOAP_NS, "Body", "SOAP-ENV:Body");
				th.endElement(SOAP_NS, "Envelope", "SOAP-ENV:Envelope");
			th.endDocument();
			writer.flush();
		}catch(Exception ee){ e.printStackTrace();}
	}
	
	static Document newDocument() throws Exception
	{
		DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
		dbf.setNamespaceAware(true);
		return dbf.newDocumentBuilder().newDocument();
	}
	
	static Document newDocument(String xml) throws Exception
	{
		DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
		dbf.setNamespaceAware(true);
		return dbf.newDocumentBuilder().parse(new InputSource(new StringReader(xml)));
	}
	
	static String makeNCName(String s)
	{
		if(s==null || s.length() == 0) return s;
		
		StringBuffer sb = new StringBuffer();
		char chars[] = s.toCharArray();

		if(!Character.isLetter(chars[0]))
			sb.append(ESCAPE_BEGIN + (int) chars[0] + ESCAPE_END);
		else
			sb.append(chars[0]);
		
		for(int i=1; i < chars.length; i++){
			if(!Character.isLetterOrDigit(chars[i]))
				sb.append(ESCAPE_BEGIN + (int) chars[i]+ ESCAPE_END);
			else
				sb.append(chars[i]);
		}
		return sb.toString();
	}
	
	static String NCNameToString(String s)
	{
		if(s==null || s.length() == 0) return s;
		
		StringBuffer sb = new StringBuffer();
		StringBuffer value = null; 
		char chars[] = s.toCharArray();
		char ch;
		int state=0;
		for(int i=0; i < chars.length; i++){

			ch = chars[i];	

			if(state == 2 && s.indexOf(ESCAPE_END, i) != i)
				value.append(ch);
			
			if(s.indexOf(ESCAPE_BEGIN, i) == i){
				state = 1;
			}
			else if(i > 1 && s.indexOf(ESCAPE_BEGIN, i-2) == i-2){
				state = 2;
				value = new StringBuffer();
			}
			else if(s.indexOf(ESCAPE_END, i) == i){
				int intValue = Integer.parseInt(value.toString());
				sb.append((char)intValue);
				state = 3;
			}
			else if(i > 1 && s.indexOf(ESCAPE_END, i-2) == i-2){
				state = 0;
			}
			else if(state == 0){
				sb.append(ch);
			}
			
		
		}
		return sb.toString();
	}
	
	Reader getQuery(String queryName)
	{
		String path = getClass().getPackage().getName().replace('.','/') + "/" + queryName;
		System.out.println("getQuery " + path);
		return new InputStreamReader(getClass().getClassLoader().getResourceAsStream(path));
	}
	
	String getQueriesFolder()
	{
		return (m_queriesFolder != null) ? 
			m_queriesFolder + File.separator 
			:
			getServletContext().getRealPath("/");
	}
	
	InputStream getRequest(HttpServletRequest request) throws Exception
	{
		String encoding = request.getHeader("Content-Encoding");
		InputStream in = null; 
		if (encoding != null && encoding.toLowerCase().indexOf("gzip") > -1)
			in = new GZIPInputStream(request.getInputStream());
		else
			in = request.getInputStream();
		
		return in; 	
	}
	
	void sendResponse(HttpServletRequest request, HttpServletResponse response, String data) throws Exception
	{
		String encoding = request.getHeader("Accept-Encoding");
		if (encoding != null && encoding.toLowerCase().indexOf("gzip") > -1){
			response.setHeader("Content-Encoding", "gzip");
			GZIPOutputStream ostream = new GZIPOutputStream(response.getOutputStream());	
			ostream.write(data.getBytes());
			ostream.flush();
			ostream.finish();
		}
		else{
			Writer writer = response.getWriter();
			writer.write(data);
			writer.flush();
		}
		
	}

}

